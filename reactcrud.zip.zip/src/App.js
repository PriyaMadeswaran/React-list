import React from 'react';
import Webpages from './components';

function App() {
  return (
    <div>
      <Webpages></Webpages>
    </div>
  );
}

export default App;
